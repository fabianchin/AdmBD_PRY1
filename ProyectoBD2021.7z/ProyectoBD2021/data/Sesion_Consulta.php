<?php

	include "ConexionBD.php";

	class SesionConsulta
	{		


		function VerificarDatos($correo,$contrasena)
		{	
			$bandera;
   			
			$conectar = new conexion();
			mysqli_set_charset($conectar, 'utf8');

			$verificar = "call Sesion_VerificarUsuario('".$correo."','".$contrasena."')";

			$resultado = $conectar->query($verificar);

			while ($fila = $resultado->fetch_assoc()) 
        	{
        		
   	 			$bandera = $fila['resultado'];
        	}	

			$conectar->close();
        	
        	return $bandera;
		}





		/*------------------------------------------------------------------------------------------------------------
		------------------------------------------------------------------------------------------------------------*/




		
		function IniciarSesion($correo,$contrasena)
		{	
			$bandera = false;
			$rol = 0;
						
			$conectar = new conexion();
			mysqli_set_charset($conectar, 'utf8');

			$verificar = "call Sesion_Iniciar('".$correo."','".$contrasena."')";

			$resultado = $conectar->query($verificar);

			while ($fila = $resultado->fetch_assoc()) 
        	{

				session_start();

				$_SESSION['rol'] =  $fila['rol_tbusuario'];
				$_SESSION['idAsociado'] =  $fila['idAsociado_tbusuario'];
				$_SESSION['nombreAsociado'] =  $fila['nombre_tbusuario'];
   	 			$rol = $fila['rol_tbusuario'];				
            	$_SESSION['carrito'] = array();
            
        	
        	}
			
			$conectar->close();
        	
        	return $rol;
		}
		
	}
?>
